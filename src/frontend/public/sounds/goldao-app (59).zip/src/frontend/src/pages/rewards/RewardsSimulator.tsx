import {
  Calculator,
  Hash,
  Loader2,
  Plus,
  RotateCcw,
  Search,
  Trash2,
} from "lucide-react";
import type React from "react";
import { useCallback, useEffect, useMemo, useState } from "react";

import { type NeuronLookup, lookupNeuron } from "@/lib/goldao-neuron";
import {
  type RoundSummary,
  buildPipeline,
  fetchLogs,
} from "@/lib/reward-events";
import {
  ASSUMPTION_DEFAULTS,
  type RewardAssumptions,
  type RewardResult,
  type TokenReward,
  poolsFrom,
  simulate,
} from "@/lib/rewards-calc";
import { computeShare, fetchNeuronMaturity } from "@/lib/rewards-canister";
import { useLiveData } from "@/lib/use-live-data";

/* number helpers */

function fmtToken(v: number): string {
  if (!Number.isFinite(v) || v === 0) return "0";
  const abs = Math.abs(v);
  const decimals = abs < 1 ? 4 : abs < 100 ? 3 : 2;
  return v.toLocaleString("en-US", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

function fmtUsd(v: number): string {
  if (!Number.isFinite(v) || v === 0) return "$0.00";
  const abs = Math.abs(v);
  const decimals = abs < 1 ? 4 : 2;
  return `$${v.toLocaleString("en-US", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })}`;
}

function fmtInt(v: number): string {
  return Math.round(v).toLocaleString("en-US");
}

function parseInput(s: string, fallback: number): number {
  const n = Number(s.replace(/,/g, "").replace(/\s/g, ""));
  return Number.isFinite(n) ? n : fallback;
}

function fmtDefault(v: number): string {
  if (v === 0) return "";
  if (v === Math.floor(v)) return Math.floor(v).toLocaleString("en-US");
  return String(v);
}

/* assumption fields for the editable panel */

type AKey = keyof RewardAssumptions;
const ASSUMPTION_FIELDS: {
  key: AKey;
  label: string;
  unit: string;
  live?: boolean;
}[] = [
  {
    key: "goldao_eligible",
    label: "Eligible GOLDAO",
    unit: "GOLDAO",
    live: true,
  },
  { key: "icp_staked", label: "ICP Staked (NNS)", unit: "ICP" },
  { key: "nns_apy", label: "NNS APY", unit: "%" },
  { key: "pct_stakers", label: "% to Stakers (ICP)", unit: "%" },
  { key: "pct_gldt", label: "% to Stakers (GLDT)", unit: "%" },
  {
    key: "ogy_pool_weekly",
    label: "OGY paid / week (avg)",
    unit: "OGY",
    live: true,
  },
  { key: "ogy_staked", label: "OGY Staked", unit: "OGY", live: true },
  { key: "ogy_apy", label: "OGY APY", unit: "%" },
  { key: "wtn_icp_annual", label: "WTN → ICP/year", unit: "ICP", live: true },
  {
    key: "origyn_ogy_icp_annual",
    label: "ORIGYN → OGY as ICP/year",
    unit: "ICP",
    live: true,
  },
  { key: "price_icp_usd", label: "ICP Price", unit: "USD", live: true },
  { key: "price_ogy_usd", label: "OGY Price", unit: "USD", live: true },
];

/* small presentational pieces (kept local to this section) */

const ACCENT: Record<string, { text: string; ring: string; soft: string }> = {
  icp: {
    text: "text-primary",
    ring: "border-border",
    soft: "border-b border-border bg-secondary/40",
  },
  gldt: {
    text: "text-[oklch(0.75_0.15_80)]",
    ring: "border-border",
    soft: "border-b border-border bg-secondary/40",
  },
  ogy: {
    text: "text-[oklch(0.65_0.18_304)]",
    ring: "border-border",
    soft: "border-b border-border bg-secondary/40",
  },
  wtn_icp: {
    text: "text-[oklch(0.7_0.12_185)]",
    ring: "border-border",
    soft: "border-b border-border bg-secondary/40",
  },
  origyn_ogy: {
    text: "text-[oklch(0.72_0.14_145)]",
    ring: "border-border",
    soft: "border-b border-border bg-secondary/40",
  },
};

function RewardCard({
  kind,
  r,
  unit,
  source,
}: {
  kind: string;
  r: TokenReward;
  unit: string;
  source: string;
}) {
  const a = ACCENT[kind] ?? ACCENT.icp;
  return (
    <div
      className={`flex flex-col overflow-hidden rounded-lg border ${a.ring} bg-card/50`}
    >
      <div className={`px-4 py-3 ${a.soft}`}>
        <div className="flex items-baseline justify-between gap-2">
          <span className={`font-display text-base font-semibold ${a.text}`}>
            {r.token}
          </span>
          <span className="shrink-0 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
            weekly
          </span>
        </div>
        <p className="mt-0.5 font-mono text-[10px] leading-snug text-muted-foreground">
          {source}
        </p>
      </div>
      <div className="flex flex-1 flex-col gap-3 px-4 py-3">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
            Per week
          </p>
          <p className={`font-mono text-2xl font-bold tabular-nums ${a.text}`}>
            {fmtToken(r.weekly)}
            <span className="ml-1.5 text-xs font-medium text-muted-foreground">
              {unit}
            </span>
          </p>
          <p className="font-mono text-xs text-muted-foreground">
            {fmtUsd(r.weekly_usd)}
          </p>
        </div>
        <dl className="mt-auto divide-y divide-border border-t border-border font-mono text-xs">
          {(
            [
              ["Per month", r.monthly, r.monthly_usd],
              ["Per year", r.annual, r.annual_usd],
            ] as const
          ).map(([label, v, usd]) => (
            <div
              key={label}
              className="grid grid-cols-[auto_1fr] items-baseline gap-x-3 py-1.5"
            >
              <dt className="text-muted-foreground">{label}</dt>
              <dd className="min-w-0 text-right">
                <span className="font-semibold tabular-nums text-foreground">
                  {fmtToken(v)}
                </span>
                <span className="block text-[11px] text-muted-foreground">
                  {fmtUsd(usd)}
                </span>
              </dd>
            </div>
          ))}
        </dl>
      </div>
    </div>
  );
}

function AssumptionField({
  field,
  value,
  onChange,
  flashing,
}: {
  field: (typeof ASSUMPTION_FIELDS)[number];
  value: string;
  onChange: (k: AKey, v: string) => void;
  flashing: boolean;
}) {
  return (
    <label className="flex items-center gap-2 py-1">
      <span className="flex w-36 shrink-0 items-center gap-1.5 font-mono text-xs text-muted-foreground">
        {field.label}
        {field.live && (
          <span
            className="inline-block size-1.5 rounded-full bg-[oklch(0.72_0.17_162)] animate-pulse"
            title="Live from API"
          />
        )}
      </span>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(field.key, e.target.value)}
        className={`min-w-0 flex-1 rounded border px-2 py-1.5 text-right font-mono text-sm text-foreground outline-none transition-colors duration-700 focus:ring-1 focus:ring-primary/50 ${
          flashing
            ? "border-[oklch(0.72_0.17_162)]/30 bg-[oklch(0.72_0.17_162)]/10"
            : "border-border bg-secondary/60"
        }`}
      />
      <span className="w-12 shrink-0 font-mono text-[10px] text-muted-foreground">
        {field.unit}
      </span>
    </label>
  );
}

/* page section */

const LIVE_TO_ASSUMPTION: Partial<Record<string, AKey>> = {
  ogy_pool_weekly: "ogy_pool_weekly",
  goldao_eligible: "goldao_eligible",
  ogy_staked: "ogy_staked",
  price_icp_usd: "price_icp_usd",
  price_ogy_usd: "price_ogy_usd",
  wtn_icp_annual: "wtn_icp_annual",
  origyn_ogy_icp_annual: "origyn_ogy_icp_annual",
};

export default function RewardsSimulator() {
  const { params: live, flash, extra } = useLiveData();
  const rewardRounds = extra.rewardRounds;

  const [raw, setRaw] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {};
    for (const [k, v] of Object.entries(ASSUMPTION_DEFAULTS)) {
      init[k] = fmtDefault(v);
    }
    return init;
  });

  // Sync live values into the editable assumptions.
  useEffect(() => {
    setRaw((prev) => {
      const next = { ...prev };
      for (const [liveKey, val] of Object.entries(live)) {
        const aKey = LIVE_TO_ASSUMPTION[liveKey];
        if (aKey && val !== undefined) next[aKey] = fmtDefault(val);
      }
      return next;
    });
  }, [live]);

  const flashSet = useMemo(() => {
    const s = new Set<string>();
    for (const k of flash) {
      const aKey = LIVE_TO_ASSUMPTION[k];
      if (aKey) s.add(aKey);
    }
    return s;
  }, [flash]);

  const [mode, setMode] = useState<"amount" | "neuron">("amount");
  const [amount, setAmount] = useState("100000");

  // Multi-neuron state
  const [neurons, setNeurons] = useState<NeuronLookup[]>([]);
  const [bulkText, setBulkText] = useState("");
  const [showBulkInput, setShowBulkInput] = useState(false);
  const [singleNeuronId, setSingleNeuronId] = useState("");
  const [lookupState, setLookupState] = useState<"idle" | "loading" | "error">(
    "idle",
  );
  const [lookupError, setLookupError] = useState("");
  const [lookupProgress, setLookupProgress] = useState("");

  const [showAssumptions, setShowAssumptions] = useState(false);

  // Recent distribution rounds from the sns_rewards log (last ~100 lines).
  const [rounds, setRounds] = useState<RoundSummary[]>([]);
  useEffect(() => {
    let cancelled = false;
    fetchLogs("sns_rewards")
      .then((logs) => {
        if (!cancelled) setRounds(buildPipeline({ sns_rewards: logs }).rounds);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, []);

  // Measured OGY pool: average of the recent paid OGY rounds.
  const ogyMeasured = useMemo(() => {
    const paid = rounds
      .map((r) => r.tokens.OGY)
      .filter((t) => t && t.status === "paid" && t.amount)
      .slice(0, 6)
      .map((t) => t!.amount as number);
    if (paid.length === 0) return null;
    return {
      weekly: paid.reduce((a, b) => a + b, 0) / paid.length,
      rounds: paid.length,
    };
  }, [rounds]);

  useEffect(() => {
    if (!ogyMeasured) return;
    setRaw((prev) => ({
      ...prev,
      ogy_pool_weekly: fmtDefault(Math.round(ogyMeasured.weekly)),
    }));
  }, [ogyMeasured]);

  const assumptions = useMemo<RewardAssumptions>(() => {
    const a: Record<string, number> = {};
    for (const [k, v] of Object.entries(raw)) {
      a[k] = parseInput(v, ASSUMPTION_DEFAULTS[k as AKey]);
    }
    return a as unknown as RewardAssumptions;
  }, [raw]);

  const handleAssumptionChange = useCallback((k: AKey, v: string) => {
    setRaw((prev) => ({ ...prev, [k]: v }));
  }, []);

  // Add a single neuron by ID
  const addSingleNeuron = useCallback(async () => {
    const id = singleNeuronId.trim();
    if (!id) return;
    setLookupState("loading");
    setLookupError("");
    try {
      const n = await lookupNeuron(id);
      setNeurons((prev) => {
        if (prev.some((x) => x.id === n.id)) return prev;
        return [...prev, n];
      });
      setSingleNeuronId("");
      setLookupState("idle");
    } catch (e) {
      setLookupError(e instanceof Error ? e.message : "Lookup failed.");
      setLookupState("error");
    }
  }, [singleNeuronId]);

  // Bulk add from textarea (one ID per line)
  const addBulkNeurons = useCallback(async () => {
    const lines = bulkText
      .split(/\n/)
      .map((l) => l.trim())
      .filter((l) => l.length > 0);
    if (lines.length === 0) return;
    setLookupState("loading");
    setLookupError("");
    const errors: string[] = [];
    let added = 0;
    for (let i = 0; i < lines.length; i++) {
      setLookupProgress(`${i + 1} / ${lines.length}`);
      try {
        const n = await lookupNeuron(lines[i]);
        setNeurons((prev) => {
          if (prev.some((x) => x.id === n.id)) return prev;
          return [...prev, n];
        });
        added++;
      } catch {
        errors.push(lines[i].slice(0, 16));
      }
    }
    setLookupProgress("");
    if (errors.length > 0) {
      setLookupError(`${added} added. Failed: ${errors.join(", ")}`);
      setLookupState("error");
    } else {
      setLookupState("idle");
    }
    setBulkText("");
    setShowBulkInput(false);
  }, [bulkText]);

  const removeNeuron = useCallback((id: string) => {
    setNeurons((prev) => prev.filter((n) => n.id !== id));
  }, []);

  // Aggregated neuron data for the model
  const neuronAgg = useMemo(() => {
    const eligible = neurons.filter((n) => n.eligible !== false);
    return {
      totalGoldao: eligible.reduce((s, n) => s + n.goldao, 0),
      totalVP: eligible.reduce((s, n) => s + (n.votingPower ?? 0), 0),
      hasVP: eligible.some((n) => n.votingPower !== null),
      allIneligible: neurons.length > 0 && eligible.length === 0,
      eligibleCount: eligible.length,
    };
  }, [neurons]);

  const neuronIneligible = mode === "neuron" && neuronAgg.allIneligible;

  const userGoldao = useMemo(() => {
    if (mode === "amount") return Math.max(parseInput(amount, 0), 0);
    if (neurons.length === 0) return 0;
    return neuronAgg.totalGoldao;
  }, [mode, amount, neurons, neuronAgg]);

  // Canister-based share: use maturity delta from get_all_neurons_maturity.
  // Fetches individual neuron delta via get_neuron_by_id when neurons change.
  // Falls back to VP proxy if canister data not yet loaded.
  const AVG_VP_MULT = 2.3;

  const [neuronDeltas, setNeuronDeltas] = useState<Record<string, bigint>>({});

  // Fetch neuron deltas from canister when neurons change
  useEffect(() => {
    if (!rewardRounds || neurons.length === 0) return;
    let cancelled = false;

    (async () => {
      const newDeltas: Record<string, bigint> = {};
      for (const n of neurons) {
        if (n.eligible === false) continue;
        const data = await fetchNeuronMaturity(n.id, rewardRounds);
        if (cancelled) return;
        if (
          data &&
          data.share !== null &&
          data.deltas[rewardRounds.referenceToken]
        ) {
          newDeltas[n.id] = data.deltas[rewardRounds.referenceToken]!;
        }
      }
      if (!cancelled) setNeuronDeltas(newDeltas);
    })();

    return () => {
      cancelled = true;
    };
  }, [neurons, rewardRounds]);

  const canisterShare = useMemo<number | undefined>(() => {
    if (mode !== "neuron" || neuronIneligible || neurons.length === 0)
      return undefined;
    if (!rewardRounds || rewardRounds.totalDelta === 0n) return undefined;

    let totalDelta = 0n;
    let foundAny = false;
    for (const n of neurons) {
      const d = neuronDeltas[n.id];
      if (d && d > 0n) {
        totalDelta += d;
        foundAny = true;
      }
    }
    if (!foundAny) return undefined;
    return computeShare(totalDelta, rewardRounds.totalDelta);
  }, [mode, neurons, neuronIneligible, rewardRounds, neuronDeltas]);

  // VP-based fallback when canister data unavailable
  const vpShare = useMemo<number | undefined>(() => {
    if (canisterShare !== undefined) return undefined;
    if (mode !== "neuron" || !neuronAgg.hasVP || neuronIneligible)
      return undefined;
    const totalVp = assumptions.goldao_eligible * AVG_VP_MULT;
    return totalVp > 0 ? neuronAgg.totalVP / totalVp : undefined;
  }, [
    canisterShare,
    mode,
    neuronAgg,
    neuronIneligible,
    assumptions.goldao_eligible,
  ]);

  const shareOverride = canisterShare ?? vpShare;

  const pools = useMemo(() => {
    const base = poolsFrom(assumptions);
    // In "by amount" mode, use active eligible as denominator if available
    if (
      shareOverride === undefined &&
      rewardRounds &&
      rewardRounds.totalNeurons > 0 &&
      rewardRounds.activeNeurons > 0 &&
      base.goldao_eligible > 0
    ) {
      base.goldao_eligible = Math.round(
        base.goldao_eligible *
          (rewardRounds.activeNeurons / rewardRounds.totalNeurons),
      );
    }
    return base;
  }, [assumptions, rewardRounds, shareOverride]);

  const result = useMemo<RewardResult>(
    () => simulate(pools, userGoldao, shareOverride),
    [pools, userGoldao, shareOverride],
  );

  const liveLoading = assumptions.goldao_eligible <= 0;
  const ogyFromRounds = assumptions.ogy_pool_weekly > 0;

  const handleReset = useCallback(() => {
    const init: Record<string, string> = {};
    for (const [k, v] of Object.entries(ASSUMPTION_DEFAULTS)) {
      init[k] = fmtDefault(v);
    }
    if (ogyMeasured)
      init.ogy_pool_weekly = fmtDefault(Math.round(ogyMeasured.weekly));
    setRaw(init);
    setAmount("100000");
    setSingleNeuronId("");
    setNeurons([]);
    setBulkText("");
    setShowBulkInput(false);
    setLookupState("idle");
    setLookupError("");
  }, [ogyMeasured]);

  return (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(300px,380px)_minmax(0,1fr)]">
        {/* input column */}
        <div className="flex flex-col gap-4">
          <div className="rounded-lg border border-border bg-card/50 p-4">
            <div className="mb-3 inline-flex rounded-lg bg-muted p-[3px]">
              <ModeButton
                active={mode === "amount"}
                onClick={() => setMode("amount")}
                icon={Calculator}
                label="By amount"
              />
              <ModeButton
                active={mode === "neuron"}
                onClick={() => setMode("neuron")}
                icon={Hash}
                label="By neuron"
              />
            </div>

            {mode === "amount" ? (
              <div className="space-y-3">
                <label className="block">
                  <span className="mb-1 block font-mono text-xs text-muted-foreground">
                    GOLDAO amount
                  </span>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="100,000"
                    className="w-full rounded-lg border border-border bg-secondary/60 px-3 py-2.5 text-right font-mono text-lg text-foreground outline-none focus:ring-1 focus:ring-primary/50"
                  />
                </label>
                <div className="flex flex-wrap gap-2">
                  {[10_000, 100_000, 1_000_000].map((v) => (
                    <button
                      key={v}
                      type="button"
                      onClick={() => setAmount(String(v))}
                      className="rounded-md border border-border bg-secondary/60 px-2.5 py-1 font-mono text-xs text-muted-foreground transition-smooth hover:bg-secondary hover:text-foreground"
                    >
                      {fmtInt(v)}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {/* Single neuron input */}
                <label className="block">
                  <span className="mb-1 block font-mono text-xs text-muted-foreground">
                    GOLDAO neuron id (hex)
                  </span>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={singleNeuronId}
                      onChange={(e) => setSingleNeuronId(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") addSingleNeuron();
                      }}
                      placeholder="a1b2c3..."
                      className="min-w-0 flex-1 rounded-lg border border-border bg-secondary/60 px-3 py-2.5 font-mono text-sm text-foreground outline-none focus:ring-1 focus:ring-primary/50"
                    />
                    <button
                      type="button"
                      onClick={addSingleNeuron}
                      disabled={
                        lookupState === "loading" || !singleNeuronId.trim()
                      }
                      className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-2.5 font-mono text-sm font-semibold text-primary-foreground transition-smooth hover:opacity-90 disabled:opacity-50"
                    >
                      {lookupState === "loading" && !showBulkInput ? (
                        <Loader2 className="size-4 animate-spin" />
                      ) : (
                        <Plus className="size-4" />
                      )}
                      Add
                    </button>
                  </div>
                </label>

                {/* Bulk add toggle */}
                <button
                  type="button"
                  onClick={() => setShowBulkInput((v) => !v)}
                  className="inline-flex items-center gap-1.5 font-mono text-xs text-primary hover:underline"
                >
                  <Plus className="size-3" />
                  {showBulkInput ? "Hide bulk input" : "Add multiple neurons"}
                </button>

                {/* Bulk textarea */}
                {showBulkInput && (
                  <div className="space-y-2">
                    <textarea
                      value={bulkText}
                      onChange={(e) => setBulkText(e.target.value)}
                      placeholder={
                        "Paste one neuron id per line:\na1b2c3...\nd4e5f6...\n7a8b9c..."
                      }
                      rows={5}
                      className="w-full rounded-lg border border-border bg-secondary/60 px-3 py-2.5 font-mono text-sm text-foreground outline-none focus:ring-1 focus:ring-primary/50 resize-y"
                    />
                    <button
                      type="button"
                      onClick={addBulkNeurons}
                      disabled={lookupState === "loading" || !bulkText.trim()}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-2 font-mono text-xs font-semibold text-primary-foreground transition-smooth hover:opacity-90 disabled:opacity-50"
                    >
                      {lookupState === "loading" && showBulkInput ? (
                        <>
                          <Loader2 className="size-3.5 animate-spin" />
                          Looking up {lookupProgress}
                        </>
                      ) : (
                        <>
                          <Search className="size-3.5" />
                          Look up all
                        </>
                      )}
                    </button>
                  </div>
                )}

                {lookupState === "error" && (
                  <p className="rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 font-mono text-xs text-destructive">
                    {lookupError}
                  </p>
                )}

                {/* Neuron list */}
                {neurons.length > 0 && (
                  <div className="space-y-2">
                    <div className="flex items-baseline justify-between">
                      <span className="font-mono text-[10px] uppercase tracking-widest text-primary">
                        Neurons ({neurons.length})
                      </span>
                      {neurons.length > 1 && (
                        <span className="font-mono text-xs font-semibold text-foreground">
                          Total: {fmtInt(neuronAgg.totalGoldao)} GOLDAO
                        </span>
                      )}
                    </div>
                    <div className="max-h-64 space-y-1.5 overflow-y-auto pr-1">
                      {neurons.map((n) => (
                        <div
                          key={n.id}
                          className="group flex items-start gap-2 rounded-md border border-border bg-secondary/40 px-3 py-2"
                        >
                          <div className="min-w-0 flex-1 space-y-0.5">
                            <p className="truncate font-mono text-[11px] text-muted-foreground">
                              {n.id}
                            </p>
                            <div className="flex flex-wrap items-baseline gap-x-4 gap-y-0.5">
                              <span className="font-mono text-sm font-semibold text-foreground">
                                {fmtInt(n.goldao)} GOLDAO
                              </span>
                              {n.votingPower !== null && (
                                <span className="font-mono text-xs text-muted-foreground">
                                  {fmtInt(n.votingPower)} VP
                                </span>
                              )}
                              <span
                                className={`font-mono text-[11px] ${
                                  n.eligible === false
                                    ? "text-destructive"
                                    : "text-[oklch(0.72_0.17_162)]"
                                }`}
                              >
                                {n.eligible === false
                                  ? "Not eligible"
                                  : n.eligible === true
                                    ? "Eligible"
                                    : "Assumed eligible"}
                              </span>
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => removeNeuron(n.id)}
                            className="mt-1 shrink-0 rounded p-1 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100 hover:text-destructive"
                            title="Remove neuron"
                          >
                            <Trash2 className="size-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* share summary */}
          <div className="rounded-lg border border-border bg-card/50 p-4">
            <div className="flex items-baseline justify-between">
              <span className="font-mono text-xs text-muted-foreground">
                {canisterShare !== undefined
                  ? "Your share by maturity delta"
                  : vpShare !== undefined
                    ? "Your share by voting power"
                    : "Your share of eligible GOLDAO"}
                {mode === "neuron" &&
                  neurons.length > 1 &&
                  ` (${neurons.length} neurons)`}
              </span>
              <span className="font-mono text-lg font-bold text-gradient-gold">
                {(result.share * 100).toLocaleString("en-US", {
                  maximumFractionDigits: 4,
                })}
                %
              </span>
            </div>
            <div className="mt-2 h-2 overflow-hidden rounded-full bg-secondary/60">
              <div
                className="h-full gradient-primary transition-[width] duration-500"
                style={{ width: `${Math.min(result.share * 100, 100)}%` }}
              />
            </div>
            {canisterShare !== undefined && rewardRounds ? (
              <div className="mt-2 space-y-0.5">
                <p className="font-mono text-[11px] text-muted-foreground">
                  Share from on-chain maturity delta (
                  {rewardRounds.activeNeurons} active neurons, ref:{" "}
                  {rewardRounds.referenceToken})
                  {rewardRounds.fromCache && " (cached)"}
                </p>
                <p className="font-mono text-[10px] text-muted-foreground/70">
                  Your neuron{neurons.length > 1 ? "s'" : "'s"} delta vs total
                  delta of all neurons that vote actively.
                </p>
              </div>
            ) : vpShare !== undefined && neuronAgg.totalVP > 0 ? (
              <div className="mt-2 space-y-0.5">
                <p className="font-mono text-[11px] text-muted-foreground">
                  {fmtInt(neuronAgg.totalVP)} VP of ~
                  {fmtInt(
                    Math.round(assumptions.goldao_eligible * AVG_VP_MULT),
                  )}{" "}
                  estimated total VP
                </p>
                <p className="font-mono text-[10px] text-muted-foreground/70">
                  Canister data loading — using VP estimate. Total VP from{" "}
                  {fmtInt(result.eligible)} eligible GOLDAO × {AVG_VP_MULT}× avg
                  multiplier.
                </p>
              </div>
            ) : (
              <p className="mt-2 font-mono text-[11px] text-muted-foreground">
                {fmtInt(userGoldao)} of {fmtInt(result.eligible)} eligible
                GOLDAO
              </p>
            )}
          </div>

          {/* assumptions */}
          <div className="overflow-hidden rounded-lg border border-border bg-card/50">
            <button
              type="button"
              onClick={() => setShowAssumptions((v) => !v)}
              className="flex w-full items-center justify-between px-4 py-2.5 text-left transition-colors hover:bg-secondary/30"
            >
              <span className="font-mono text-[10px] uppercase tracking-widest text-primary">
                Assumptions & live inputs
              </span>
              <svg
                width="14"
                height="14"
                viewBox="0 0 14 14"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                role="img"
                aria-label="Toggle assumptions"
                className={`text-muted-foreground transition-transform duration-200 ${
                  showAssumptions ? "rotate-180" : ""
                }`}
              >
                <path d="M3.5 5.5L7 9l3.5-3.5" />
              </svg>
            </button>
            <div
              className="grid transition-[grid-template-rows] duration-200"
              style={{ gridTemplateRows: showAssumptions ? "1fr" : "0fr" }}
            >
              <div className="overflow-hidden">
                <div className="px-4 pb-3">
                  {ASSUMPTION_FIELDS.map((f) => (
                    <AssumptionField
                      key={f.key}
                      field={f}
                      value={raw[f.key]}
                      onChange={handleAssumptionChange}
                      flashing={flashSet.has(f.key)}
                    />
                  ))}
                  <button
                    type="button"
                    onClick={handleReset}
                    className="mt-2 inline-flex items-center gap-1.5 rounded-lg border border-border bg-secondary/60 px-3 py-1.5 font-mono text-xs text-muted-foreground transition-smooth hover:bg-secondary hover:text-foreground"
                  >
                    <RotateCcw className="size-3.5" />
                    Reset
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* results column */}
        <div className="flex flex-col gap-4">
          {liveLoading && (
            <p className="rounded-md border border-primary/30 bg-primary/10 px-3 py-2 font-mono text-xs text-primary">
              Loading live data (eligible GOLDAO, prices)… estimates fill in
              once it arrives.
            </p>
          )}
          {rewardRounds && (
            <p className="rounded-md border border-[oklch(0.72_0.17_162)]/30 bg-[oklch(0.72_0.17_162)]/10 px-3 py-2 font-mono text-xs text-[oklch(0.72_0.17_162)]">
              <span className="inline-block size-1.5 rounded-full bg-[oklch(0.72_0.17_162)] mr-1.5 align-middle" />
              On-chain maturity data ({rewardRounds.totalNeurons} neurons,{" "}
              {rewardRounds.activeNeurons} active, ref:{" "}
              {rewardRounds.referenceToken})
              {rewardRounds.fromCache && " — cached"}
            </p>
          )}
          {neuronIneligible && (
            <p className="rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 font-mono text-xs text-destructive">
              {neurons.length === 1
                ? "This neuron is dissolving or under the 2-year lock — it does not accrue rewards."
                : "All selected neurons are dissolving or under the 2-year lock — none accrue rewards."}
            </p>
          )}

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <RewardCard
              kind="icp"
              r={result.icp}
              unit="ICP"
              source="33% of NNS neuron maturity"
            />
            <RewardCard
              kind="gldt"
              r={result.gldt}
              unit="ICP eq."
              source="33% of NNS maturity, paid as GLDT monthly"
            />
            <RewardCard
              kind="ogy"
              r={result.ogy}
              unit="OGY"
              source={
                ogyFromRounds
                  ? `DAO OGY neuron + ORIGYN partnership · avg of last ${ogyMeasured?.rounds ?? ""} rounds`
                  : "DAO OGY neuron · staked × APY"
              }
            />
            <RewardCard
              kind="wtn_icp"
              r={result.wtn_icp}
              unit="ICP"
              source="WaterNeuron 10% fee · Gold DAO VP share"
            />
            {!ogyFromRounds && (
              <RewardCard
                kind="origyn_ogy"
                r={result.origyn_ogy}
                unit="ICP eq."
                source="ORIGYN partnership OGY, shown in ICP value"
              />
            )}
          </div>

          <div className="rounded-lg border border-primary/30 bg-card/50 p-4">
            <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-primary">
              Recurring total (ICP + GLDT + OGY + WTN
              {ogyFromRounds ? "" : " + ORIGYN"})
            </p>
            <div className="grid grid-cols-3 items-end gap-4">
              <div>
                <p className="font-mono text-[11px] text-muted-foreground">
                  Per week
                </p>
                <p className="font-mono text-lg font-bold tabular-nums text-foreground sm:text-2xl">
                  {fmtUsd(result.total_weekly_usd)}
                </p>
              </div>
              <div className="text-right">
                <p className="font-mono text-[11px] text-muted-foreground">
                  Per month
                </p>
                <p className="font-mono text-lg font-bold tabular-nums text-foreground sm:text-2xl">
                  {fmtUsd(result.total_monthly_usd)}
                </p>
              </div>
              <div className="text-right">
                <p className="font-mono text-[11px] text-muted-foreground">
                  Per year
                </p>
                <p className="font-mono text-lg font-bold tabular-nums text-gradient-gold sm:text-2xl">
                  {fmtUsd(result.total_annual_usd)}
                </p>
              </div>
            </div>
            <p className="mt-3 font-mono text-[10px] leading-relaxed text-muted-foreground">
              Weekly averages, not a promise for any single week: ICP arrives
              when the NNS neuron&apos;s spawns are disbursed, so some weeks pay
              none and the next pays more. OGY uses the amount actually paid in
              recent rounds, which already includes the ORIGYN partnership. GLDT
              is paid monthly. In neuron mode, share comes from your on-chain
              maturity delta.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function ModeButton({
  active,
  onClick,
  icon: Icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ComponentType<{ className?: string }>;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 font-mono text-xs font-medium transition-smooth ${
        active
          ? "bg-background text-foreground shadow-sm"
          : "text-muted-foreground hover:text-foreground"
      }`}
    >
      <Icon className="size-3.5" />
      {label}
    </button>
  );
}
